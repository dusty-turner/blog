# Note: I used Fira Sans and Mono (downloaded here from Google Fonts).
#       Feel free to change font names below for desired fonts.

sysfonts::font_add_google("Fira Sans")
sysfonts::font_add_google("Fira Mono")
showtext::showtext_auto()
options(tidy_verb_anim.font_registered = TRUE)
